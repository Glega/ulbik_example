export interface IUser {
    
    id: string;
    email: string;
    isActive: boolean;
    
}