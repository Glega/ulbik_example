// eslint-disable-next-line @typescript-eslint/no-unused-vars
import React, {FC, useContext, useEffect} from 'react';
import LoginForm from './components/LoginForm';
import { observer } from 'mobx-react-lite';
import { Context } from './index';


const App: FC = () => {

  const {store} = useContext(Context)

  useEffect(() => {
    if(localStorage.getItem('token')){
      store.checkAuth()
    }
  });

  return (
    <div>
      <h1>{store.isAuth ? 'Zalupa' : 'Авторизируйся падла!'}</h1>
      <LoginForm/>
    </div>
  );
}

export default observer(App);
