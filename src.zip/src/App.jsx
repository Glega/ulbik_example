import Content from "./components/Content";
import Profile from "./components/Profile";
import SideBar from "./components/SideBar";
import './App.css'
import SinglePage from "./page/SinglePage";

const App = () => {
  return (
    <div className="dashboard">
      <div>
      <SideBar />
      </div>
      <div className="dashboard--content">
        <Content />
        <Profile />
        <SinglePage />
      </div>
    </div>
  );
}

export default App;