export const sum = (numbers: number[]) =>
    numbers.reduce((acc, value) => acc + value, 0)