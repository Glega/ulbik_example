import './SinglePage.scss'

const SinglePage = () => {
    return (
        <div className='home'>
            sdfdsf
        </div>
    );
};

export default SinglePage;