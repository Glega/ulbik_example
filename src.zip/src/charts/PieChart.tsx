import { useMemo } from "react"
import { HSLA } from "../ui/colors/HSLA"
import { sum } from "../ui/colors/sun"
import { SvgArc, polarToCartesian } from "./SvgArc"
import React from "react"

export interface PieChartItem {
    value: number
    color: HSLA
    labelColor?: HSLA
  }
  
  interface Props {
    items: PieChartItem[]
  }
  
  const cutoutRadiusShare = 0.6
  const totalDegrees = 360
  const spaceBetweenInDegrees = 1.8
  
  interface PieChartItemWithAngle extends PieChartItem {
    startAngle: number
    endAngle: number
  }
  
  const getItemsWithAngles = (items: PieChartItem[]): PieChartItemWithAngle[] => {
    const total = sum(items.map((item) => item.value))
  
    const itemsWithAngles: PieChartItemWithAngle[] = []
  
    items.forEach((item, index) => {
      const startAngle = index === 0 ? 0 : itemsWithAngles[index - 1].endAngle
      const endAngle = startAngle + (item.value / total) * totalDegrees
  
      itemsWithAngles.push({
        ...item,
        startAngle,
        endAngle,
      })
    })
  
    return itemsWithAngles
  }

  export const degreesInCircle = 360

  export const degreesToRadians = (degrees: number) =>
  degrees * (Math.PI / (degreesInCircle / 2))

  export const labelColorsCount = 12

  export const generateLabelColorGetter =
  ({ saturation, lightness }) =>
  (labelIndex: number): HSLA => {
    const labelIndexOnInterval =
      (labelIndex % labelColorsCount) / labelColorsCount

    const hue = degreesInCircle * labelIndexOnInterval

    return new HSLA(hue, saturation, lightness)
  }

  const backgroundHue = 0
  const backgroundSaturation = 0

  export const sharedColors = {
    primary: new HSLA(210, 77, 51),  
    white: new HSLA(0, 0, 100),
    transparent: new HSLA(0, 0, 0, 0),
  } as const

  export const darkTheme = {
    name: 'dark',
    colors: {
      ...sharedColors,
  
      success: new HSLA(130, 56, 52),
      alert: new HSLA(0, 79, 63),
      idle: new HSLA(32, 79, 48),
  
      foreground: new HSLA(backgroundHue, backgroundSaturation, 12),
      background: new HSLA(backgroundHue, backgroundSaturation, 8),
      text: new HSLA(0, 0, 100, 0.81),
      textSupporting: new HSLA(0, 0, 61),
      textShy: new HSLA(0, 0, 100, 0.28),
  
      mist: new HSLA(0, 0, 100, 0.06),
      mistExtra: new HSLA(0, 0, 100, 0.13),
  
      overlay: new HSLA(backgroundHue, backgroundSaturation, 1, 0.8),
  
      getLabelColor: generateLabelColorGetter({
        saturation: 56,
        lightness: 52,
      }),
  
      contrast: new HSLA(0, 0, 100),
    },
    shadows: {
      small:
        'rgb(15 15 15 / 20%) 0px 0px 0px 1px, rgb(15 15 15 / 20%) 0px 2px 4px',
      medium:
        'rgb(15 15 15 / 10%) 0px 0px 0px 1px, rgb(15 15 15 / 20%) 0px 3px 6px, rgb(15 15 15 / 40%) 0px 9px 24px;',
    },
  }

  
  
  const svgViewBoxSize = 500
  const labelSize = 360

  export const PieChart = ({ items }: Props) => {
    const { colors } = darkTheme;
    const itemsWithAngles = useMemo(() => {
        const result = getItemsWithAngles(items.filter((item) => item.value > 0))
    
        if (!result.length) {
          result.push({
            value: 1,
            color: colors.foreground,
            startAngle: 0,
            endAngle: totalDegrees,
          })
        }
    
        return result
      }, [colors, items])
    
      const radius = svgViewBoxSize / 2
      const cutoutRadius = radius * cutoutRadiusShare
    
      const total = sum(items.map((item) => item.value))
    
      return (
        <svg viewBox={`0 0 ${svgViewBoxSize} ${svgViewBoxSize}`}>
          {itemsWithAngles.map(
            (
              { color, startAngle, endAngle, value, labelColor = colors.contrast },
              index,
            ) => {
              if (value === 0) {
                return null
              }
              const labelAngle = startAngle + (endAngle - startAngle) / 2
              const labelPosition = polarToCartesian(
                radius,
                cutoutRadius + (radius - cutoutRadius) / 2,
                labelAngle,
              )
              labelPosition.x -= labelSize / 2
              labelPosition.y -= labelSize / 2
    
              const percentage = Math.round((value * 100) / total)
    
              return (
                <React.Fragment key={index}>
                  <SvgArc
                    color={color.getVariant({ a: (a) => a * 0.2 })}
                    radius={radius}
                    cutoutRadius={cutoutRadius}
                    startAngle={startAngle}
                    endAngle={endAngle - spaceBetweenInDegrees}
                  />
                  <SvgArc
                    color={color}
                    radius={radius}
                    cutoutRadius={radius * 0.96}
                    startAngle={startAngle}
                    endAngle={endAngle - spaceBetweenInDegrees}
                  />
                  {percentage > 5 && itemsWithAngles.length > 1 && (
                    
                    <g>
                    <rect
                      fill="transparent"
                      {...labelPosition}
                      width={labelSize}
                      height={labelSize}
                    />
                    <text
                      x={labelPosition.x + labelSize / 2}
                      y={labelPosition.y + labelSize / 2}
                      dominantBaseline="middle"
                      textAnchor="middle"
                      fill={labelColor.toCssValue()}
                      style={{fontSize: 9, fontWeight: 400}}
                    >
                      {percentage}
                      <tspan fill={labelColor.toCssValue()} fontSize={7}>
                        {' '}
                        %
                      </tspan>
                    </text>
                  </g>
                    
                  )}
                </React.Fragment>
              )
            },
          )}
        </svg>
    )
  }