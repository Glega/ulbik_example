// eslint-disable-next-line no-unused-vars
import React from 'react';
import ContentHeader from './ContentHeader';
import '../styles/content.css'
import Card from './Card';
import { PieChart } from "../charts/PieChart";
import { HSLA } from "../ui/colors/HSLA"

// eslint-disable-next-line no-unused-vars
const Content = (props) => {
    return (
        <div className='content'>
            <PieChart items={[{value:20, color: new HSLA(119, 50, 37)}, {value:80, color: new HSLA(147, 50, 47)}]}/>
            
           <ContentHeader />
           <Card />
        </div>
    );
}

export default Content;