import { BiHome, BiBookAlt, BiMessage, BiStats, BiSolidReport, BiHelpCircle } from "react-icons/bi";
import '../styles/sidebar.css'


const SideBar = () => {
    return (
        <div className="menu">
            <div className="logo">
                <BiBookAlt className="icon"/>
                <h2>Fucj</h2>
            </div> 

            <div className="menu--list">
                <a href="#" className="item">
                    <BiHome className="icon"/>
                    Dashboard
                </a>
                <a href="#" className="item">
                    <BiMessage className="icon"/>
                    Message
                </a>
                <a href="#" className="item">
                    <BiStats className="icon"/>
                    Sttats
                </a>
                <a href="#" className="item">
                    <BiSolidReport className="icon"/>
                    rrrr
                </a>
                <a href="#" className="item">
                    <BiHelpCircle className="icon"/>
                    Help
                </a>
            </div>
        </div>
    );
}

export default SideBar;