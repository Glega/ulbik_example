// eslint-disable-next-line no-unused-vars
import React from 'react';

// eslint-disable-next-line no-unused-vars
const Profile = (props) => {
    return (
        <div>
            Profile
        </div>
    );
}

export default Profile;