import './App.css'
import CheckBox from './component/checkbox';
import ScrollTable from './component/scrollTable';

import VirtualScrollTable from './component/vtable';

const App = () => {
    return (
        <div>        
            <CheckBox />        
            <table border="1">
                <tr>
                    <td><span  class="cut-text">Этот текст слишком длинный для ячейки таблицы и должен быть обрезан...</span></td>
                    <td>Другая ячейка</td>
                </tr>            
            </table>
            <ScrollTable />
        </div>
    )
}

export default App;