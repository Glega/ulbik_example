import React from 'react';

function CheckBox(props) {
    return (
        <div class="checkbox-container">
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 1</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 2</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 3</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 4</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 1</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 2</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 3</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 4</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 1</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 2</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 3</label>
        </div>
        <div class="checkbox-item">
            <input type="checkbox" id="checkbox1" />
            <label for="checkbox1">Checkbox 4</label>
        </div>
      </div>
    );
}

export default CheckBox;