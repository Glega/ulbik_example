import React, { useState, useRef, useCallback } from 'react';


const VirtualScrollTable = () => {
  const allItems = Array.from({ length: 500 }, (_, i) => i + 1);
  const viewportHeight = 400; // Высота области просмотра таблицы (px)
  const rowHeight = 50; // Высота одной строки (px)
  const bufferSize = 5; // Количество строк в буфере (для плавности скролла)

  // Состояние для индекса первого и последнего видимого элемента
  const [range, setRange] = useState({ start: 0, end: bufferSize + Math.ceil(viewportHeight / rowHeight) });

  const rowCount = allItems.length; // Общее количество строк
  const innerHeight = rowCount * rowHeight; // Высота всего списка

  const startOffset = range.start * rowHeight; // Смещение начала видимого списка

  const tableRef = useRef(null);

  // Функция для обработки события скролла
  const onScroll = useCallback(() => {
    const viewportTop = tableRef.current.scrollTop;
    const currentStart = Math.floor(viewportTop / rowHeight);
    const currentEnd = Math.ceil(viewportTop / rowHeight) + Math.ceil(viewportHeight / rowHeight) + bufferSize;
    setRange({ start: currentStart, end: currentEnd });
  }, [rowHeight, viewportHeight, bufferSize]);

  // Элементы, которые будут отрендерены
  const visibleItems = allItems.slice(range.start, range.end);

  return (
    <div className="viewport" ref={tableRef} onScroll={onScroll} style={{ height: `${viewportHeight}px`, overflowY: 'scroll' }}>
      <div style={{ height: `${innerHeight}px`, position: 'relative', top: `${startOffset}px`}}>
        {visibleItems.map((item) => (
          <div className="row" key={item} style={{ height: `${rowHeight}px` }}>{`Row ${item}`}</div>
        ))}
      </div>
    </div>
  );
};

export default VirtualScrollTable;
