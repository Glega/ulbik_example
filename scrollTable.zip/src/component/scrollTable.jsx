import React, { useState, useRef, useCallback } from 'react';

const ScrollTable = () => {
    const allItems = Array.from({ length: 500 }, (_, i) => i + 1);
    const viewportHeight = 400; // Высота видимого пространства в пикселях.
    const rowHeight = 50; // Высота одного элемента (строки) в пикселях.
    const bufferSize = 5; // Количество элементов в буфере.
    
    const [visibleRange, setVisibleRange] = useState({ start: 0, end: Math.ceil(viewportHeight / rowHeight) + bufferSize });
    
    const tableRef = useRef(); // Реф на область просмотра (viewport).

    const handleScroll = useCallback(() => {
        const scrollTop = tableRef.current.scrollTop;
        const start = Math.floor(scrollTop / rowHeight) - bufferSize;
        const end = start + Math.ceil(viewportHeight / rowHeight) + 2 * bufferSize;
        
        setVisibleRange({ start: Math.max(0, start), end });
    }, [rowHeight, viewportHeight, bufferSize]); // Зависимости useCallback.

    const visibleItems = allItems.slice(visibleRange.start, visibleRange.end);

    return (
        <div
            ref={tableRef}
            style={{ height: `${viewportHeight}px`, overflowY: 'auto', position: 'relative' }}
            onScroll={handleScroll}
        >
            <table className='table' style={{ marginTop: `${visibleRange.start * rowHeight}px` }}>
                <thead style={{position:'sticky', top: 0}}>
                    <tr><th>Row</th></tr>
                </thead>
                <tbody>
                    {visibleItems.map(item => (
                        <tr key={item} style={{ height: `${rowHeight}px` }}>
                            <td>{`Item ${item}`}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ScrollTable;
