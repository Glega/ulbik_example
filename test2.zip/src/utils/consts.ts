export const ADMIN_ROUTE = '/admin'
export const LOGIN_ROUTE = '/login'
export const REGISTRATION_ROUTE = '/registration'
export const DASHBOARD_ROUTE = '/dashBoard'
export const INDEX_ROUTE = '/'


