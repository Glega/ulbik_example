
import Admin from "./pages/Admin";
import DashBoard from "./pages/DashBoard";
import IndexPage from "./pages/IndexPage";
import { ADMIN_ROUTE, DASHBOARD_ROUTE, INDEX_ROUTE, LOGIN_ROUTE } from "./utils/consts";
import Auth from "./pages/Auth";

export const authRoutes = [
    {
        path: DASHBOARD_ROUTE,
        Component: DashBoard,
    },
    {
        path: ADMIN_ROUTE,
        Component: Admin,
    }
];

export const publicRoutes = [    
    {
        path: INDEX_ROUTE,
        Component: IndexPage,
    },
    {
        path: LOGIN_ROUTE,
        Component: Auth
    }

];