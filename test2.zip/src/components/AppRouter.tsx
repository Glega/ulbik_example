import React, { useContext } from 'react';
import {Routes, Route, Navigate} from 'react-router-dom'
import { authRoutes, publicRoutes } from '../routes';
import { INDEX_ROUTE } from '../utils/consts';
import { Context } from '..';
import { observer } from 'mobx-react-lite';


const AppRouter = () => {

    const {store} = useContext(Context)

    const isAuth = store.isAuth;

    console.log(`isAuth = ${isAuth}`)

    return (
        <Routes>
            {isAuth && authRoutes.map(({path, Component}) =>
                <Route key={path} path={path} Component={Component} />

            )}
            {publicRoutes.map(({path, Component}) =>
                <Route key={path} path={path} Component={Component} />

            )}
            <Route path='*' element={<Navigate to={INDEX_ROUTE} />} />
        </Routes>
    );
};

export default observer(AppRouter);