import React from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { NavLink, useNavigate } from 'react-router-dom';
import { INDEX_ROUTE, LOGIN_ROUTE } from '../utils/consts';
import { Button } from 'react-bootstrap';

const MyBar = () => {

    const navigate = useNavigate()

    return (
        <Navbar bg="dark" variant='dark'>
        <Container>
          <NavLink to={INDEX_ROUTE}>ZALUPA</NavLink>
          <Nav className='ml-auto'>
            <Button variant={'outline-light'}>Admin</Button>
            <Button onClick={() => navigate(LOGIN_ROUTE)} className='ml-2' variant={'outline-light'}>Autho</Button>
          </Nav>
        </Container>
      </Navbar>
    );
};

export default MyBar;