import React, { createContext } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import Store from './store/store';
import LinStore from './store/linStore';

interface State {
  store: Store,
  lin: LinStore
}

const store = new Store();
const lin = new LinStore()

export const Context = createContext<State>({
  store,  
  lin
})

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
    <Context.Provider value={{
      store,
      lin,
    }}>
      <App />
    </Context.Provider>
    
  </React.StrictMode>
);
