// eslint-disable-next-line @typescript-eslint/no-unused-vars
import React, {FC, useContext, useEffect} from 'react';

import { observer } from 'mobx-react-lite';
import { Context } from './index';
import { BrowserRouter } from 'react-router-dom';
import AppRouter from './components/AppRouter';

import { jwtDecode } from 'jwt-decode';


const App: FC = () => {

  const {store} = useContext(Context)

  const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IlphbHVwYSEhISIsImlhdCI6MTUxNjIzOTAyMn0.frf2sMrWjf3mry9H6tFHyJdB3krJGRQN4pcOrBnlCqw"
  console.log(jwtDecode(token))

  useEffect(() => {
    if(localStorage.getItem('token')){
      store.checkAuth()
    }
  });

  return (
    <BrowserRouter>
    {/*
    <div>
      <h1>{store.isAuth ? 'Zalupa' : 'Авторизируйся падла!'}</h1>
      <LoginForm/>
    </div>
    */}   
      
      <AppRouter /> 
    </BrowserRouter>
    
  );
}

export default observer(App);
