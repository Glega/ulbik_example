import React from 'react';
import MyBar from '../components/MyBar';

const DashBoard = () => {
    return (
        <div>
            <MyBar />
        </div>
    );
};

export default DashBoard;