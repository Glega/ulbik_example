import React from 'react';
import MyBar from '../components/MyBar';

const IndexPage = () => {
    return (
        <div>
            <MyBar />
            INDEX
        </div>
    );
};

export default IndexPage;