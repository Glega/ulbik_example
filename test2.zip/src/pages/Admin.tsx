import React from 'react';

const Admin = () => {
    return (
        <div>
            I'm ADMIN!!!!1
        </div>
    );
};

export default Admin;