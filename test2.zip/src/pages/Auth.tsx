import React, { useContext, useState } from 'react';
import {useNavigate} from 'react-router-dom'
import { Button, Col, Container, Row, Image, InputGroup, FormControl } from 'react-bootstrap';
import { ADMIN_ROUTE } from '../utils/consts';
import { observer } from 'mobx-react-lite';
import { Context } from '..';


const Auth = observer(() => {
    const history = useNavigate();
    const {store} = useContext(Context)
    const [isLogin, setLoginFlag] = useState(false);
    

    const click = async () => {
        setLoginFlag(true);
        await new Promise(resolve => setTimeout(resolve, 2000));        
        store.setAuth(true);
        history(ADMIN_ROUTE);
        setLoginFlag(false);
    }


    return (
        <Container className='d-flex justify-content-center align-items-center min-vh-100'>
            {/*<Button onClick={click}>
                LOGIN
            </Button> */}
            <Row className='border rounder-5 p-3 bg-white shadow'>
                <Col className='col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box' style={{background: 'black'}}>
                    <div className='featured-image mb-3'>
                        <Image className='img-fluid' src='https://www.monocrystal.ru/content/section/9b926217fdffaf4d0ce8ad98a76fd1a1.jpg'></Image>                
                    </div>
                    <div style={{position: 'absolute'}}>
                        <p className='text-white fs-2'>Be verified</p>
                        <small className='text-white text-wrap text-left'>Jowerwerwerrrrrrrrrrrrrrrinqweqweqwewe in our cab</small>
                    </div>
                    
                </Col>
                <Col className='col-md-6'>
                    <Row className='align-items-center'>
                        <div className='header-text mb-4'>
                            <p>Hello, Again</p>
                            <p>Welcome aboard, pidr</p>
                        </div>
                        <InputGroup className='mb-3'>                            
                            <InputGroup.Text className='text-black' id="login">{'Login'}</InputGroup.Text>
                            <FormControl 
                                placeholder='Type login here...'
                                area-label='Login'
                                aria-describedby="login"
                            />                            
                        </InputGroup>
                        <InputGroup className='mb-3'>                            
                            <InputGroup.Text className='text-black' id="password">Password</InputGroup.Text>
                            <FormControl 
                                placeholder='Type password here...'
                                area-label='Password'
                                aria-describedby="password"
                            />                            
                        </InputGroup>
                    </Row>
                    <Row className='align-items-center'>
                        <div className='ml-auto'>
                            <Button className='ml-auto' variant='dark' onClick={click} disabled={isLogin}>
                            {isLogin ? 
                            <div>
                                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                <span className="sr-only ms-2">Loading...</span>
                            </div>
                            : 'Login'
                            }
                            </Button>
                            

                        </div>                        
                    </Row>
                </Col>
            </Row>
            
        </Container>
    );
});

export default Auth;