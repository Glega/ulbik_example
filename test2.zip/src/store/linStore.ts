import { makeAutoObservable } from "mobx";

export default class LinStore {

    _lins: string = '';

    constructor(){
        makeAutoObservable(this);
    }

    setDevice(_lins:string){
        this._lins = _lins
    }

    get lins(): string {
        return this._lins;
    }
}